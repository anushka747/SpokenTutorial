from cgitb import text
from django.http import HttpResponse
from django.shortcuts import redirect, render
from django.core.files.storage import FileSystemStorage
from . import forms
import pyttsx3
import os

# Create your views here.

def TranscriptUploadView(request):
    text_speech = pyttsx3.init()
    text_speech.setProperty('rate', 130)
    voices = text_speech.getProperty('voices')

    if request.method == 'POST': # if the submitted method is POST
        form = forms.UploadTranscriptForm(request.POST,request.FILES) # get the transcipt form submitted by the user
        uploadedFileName = request.FILES['transcript'].name # get the file name of the uploaded transcript
        if form.is_valid():
            form.save() # save the uploaded transcript file
            voiceType = request.POST.get('gender') # get the gender as submitted by the user
            if(voiceType == False): # False = male voice
                text_speech.setProperty('voice', voices[0].id)
            else:
                text_speech.setProperty('voice', voices[1].id)
            # preparing input from the transcipt file
            file = open("media/transcripts/"+uploadedFileName)
            answer = ""
            for line in file:
                answer += line
            # Saves the file in text_to_voice file
            text_speech.save_to_file(answer, 'text_to_voice.mp3')
            text_speech.runAndWait()
            return redirect('http://localhost:8000/merge') # redirect to the next step
    else: # for other methods than POST e.g. GET
        form = forms.UploadTranscriptForm()
        context = {
            'form':form,
        }
    return render(request, 'UploadTranscript.html', context)


def VideoMergeView(request):
    # if the request is from post method
    if request.method == 'POST':
        form = forms.UploadVideosForm(request.POST, request.FILES)
        if form.is_valid():
            form.save() #save the form if the submitted form is valid
        videoFile = request.FILES['video'].name # get the video file name
        audioFile = request.FILES['audio'].name # get the audio file name

        # stripping
        os.system("ffmpeg -i "+"media/videos/"+videoFile+" -an strippedFile.mp4")

        # merge audio and video
        os.system("ffmpeg -i strippedFile.mp4 -i "+"media/audios/"+audioFile+" -c:v copy -c:a aac mergedFile.mp4")

        # compress the video
        os.system("ffmpeg -i mergedFile.mp4 -vcodec libx265 -crf 28 compressedFile.mp4")

        # delete the temporary files created
        os.system("del mergedFile.mp4")
        os.system("del strippedFile.mp4")
        # os.system("del compressedFile.mp4")

        # after all the work is done, redirect to the next page i.e. preview page
        return redirect("http://localhost:8000/preview")

    else: # if the request if from any method other than post method e.g. GET method
        form = forms.UploadVideosForm()
        context = {
            'form':form,
        }
        return render(request, 'MergeFiles.html', context)


def Preview(request):
    # pass the video file as props to the Preview.html
    context = {
        "videoFile": "media/videos/videoplayback1.mp4"
    }
    return render(request,"Preview.html", context)