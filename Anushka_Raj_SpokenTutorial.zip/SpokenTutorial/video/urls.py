from django.conf.urls.static import static
from unicodedata import name
from django.conf import settings
from django.urls import path
from . import views

urlpatterns = [
    path('', views.TranscriptUploadView, name ='BookUploadView'),
    path('merge', views.VideoMergeView, name ='VideoMergeView'),
    path('preview', views.Preview, name ='Preview')
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)