from django.db import models

# Create your models here.
class TranscriptsModel(models.Model):
    transcript = models.FileField(upload_to='transcripts/', default="Transcript")
    gender = models.BooleanField("Female")
     
    def __str__(self):
        return "upload transcript"

class MergeVideosModel(models.Model):
    video = models.FileField(upload_to='videos/')
    audio = models.FileField(upload_to='audios/')
    def __str__(self):
        return "merge videos"